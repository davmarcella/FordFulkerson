package networkFlow;

public class Tester {
	
	public static void createGraph(){
		NetworkGraph n = new NetworkGraph();
		n.addEdge("A", "B");
	}
}
